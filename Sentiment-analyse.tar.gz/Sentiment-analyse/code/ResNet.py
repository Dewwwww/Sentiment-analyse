import pandas as pd
import re
import jieba.posseg as psg
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.optim as optim
from torch.nn.utils.rnn import pad_sequence
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
import os
import sys
import logging

# 配置日志记录
logging.basicConfig(
    filename='ResNet_Sentiment.log',  # 日志文件名
    filemode='w',                     # 覆盖模式
    level=logging.INFO,               # 记录级别
    format='%(asctime)s - %(levelname)s - %(message)s'  # 日志格式
)

# 检查设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
logging.info(f"Using device: {device}")
print(f"Using device: {device}")

# 确认 CUDA 详细信息
if torch.cuda.is_available():
    logging.info(f"CUDA is available. Number of GPUs: {torch.cuda.device_count()}")
    print(f"CUDA is available. Number of GPUs: {torch.cuda.device_count()}")
    for i in range(torch.cuda.device_count()):
        gpu_name = torch.cuda.get_device_name(i)
        logging.info(f"GPU {i}: {gpu_name}")
        print(f"GPU {i}: {gpu_name}")
else:
    logging.info("CUDA is not available.")
    print("CUDA is not available.")

# 文本清洗
def clean_text(text):
    """
    清洗文本，去除英文、数字和空白字符。
    """
    pattern = re.compile('[a-zA-Z0-9]+|[\s]+')
    return pattern.sub('', text)

# 分词
def tokenize(text):
    """
    使用jieba进行中文分词。
    """
    return ' '.join([x.word for x in psg.cut(text)])

# 数据预处理
def preprocess_reviews(neg_file, pos_file):
    """
    读取负面和正面评论文件，进行清洗和分词，返回包含评论和标签的DataFrame。
    """
    try:
        logging.info(f"Reading negative reviews from {neg_file}...")
        print(f"Reading negative reviews from {neg_file}...")
        with open(neg_file, 'r', encoding='utf-8') as file:
            neg_reviews = file.readlines()
        neg_reviews = [clean_text(line.strip()) for line in neg_reviews]
        logging.info(f"Number of negative reviews: {len(neg_reviews)}")
        print(f"Number of negative reviews: {len(neg_reviews)}")
        
        logging.info(f"Reading positive reviews from {pos_file}...")
        print(f"Reading positive reviews from {pos_file}...")
        with open(pos_file, 'r', encoding='utf-8') as file:
            pos_reviews = file.readlines()
        pos_reviews = [clean_text(line.strip()) for line in pos_reviews]
        logging.info(f"Number of positive reviews: {len(pos_reviews)}")
        print(f"Number of positive reviews: {len(pos_reviews)}")
        
        # 创建DataFrame
        data = {'comment': neg_reviews + pos_reviews,
                'label': [0] * len(neg_reviews) + [1] * len(pos_reviews)}
        df = pd.DataFrame(data)
        logging.info("Tokenizing comments...")
        print("Tokenizing comments...")
        df['tokens'] = df['comment'].apply(tokenize)
        return df
    except Exception as e:
        logging.error(f"Error during preprocessing reviews: {e}")
        print(f"Error during preprocessing reviews: {e}")
        sys.exit(1)

# 建立词汇表
def build_vocab(reviews):
    """
    根据分词后的评论建立词汇表，词汇表索引从1开始，<pad>标记为0。
    """
    try:
        logging.info("Building vocabulary...")
        print("Building vocabulary...")
        vocab = {}
        for tokens in reviews['tokens']:
            for word in tokens.split():
                if word not in vocab:
                    vocab[word] = len(vocab) + 1  # 词汇表索引从1开始
        vocab['<pad>'] = 0
        logging.info(f"Vocabulary size: {len(vocab)}")
        print(f"Vocabulary size: {len(vocab)}")
        return vocab
    except Exception as e:
        logging.error(f"Error during building vocabulary: {e}")
        print(f"Error during building vocabulary: {e}")
        sys.exit(1)

# 定义数据集类
class ReviewsDataset(Dataset):
    def __init__(self, reviews, vocab, include_labels=True):
        """
        初始化数据集。
        :param reviews: 包含评论和标签的DataFrame
        :param vocab: 词汇表字典
        :param include_labels: 是否包含标签
        """
        self.reviews = reviews
        self.vocab = vocab
        self.include_labels = include_labels

    def __len__(self):
        return len(self.reviews)

    def __getitem__(self, idx):
        tokens = [self.vocab.get(word, 0) for word in self.reviews.iloc[idx]['tokens'].split()]
        tokens_tensor = torch.tensor(tokens, dtype=torch.long)
        if self.include_labels:
            label = self.reviews.iloc[idx]['label']
            return tokens_tensor, torch.tensor(label, dtype=torch.long)
        return tokens_tensor

# 定义残差块
class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding):
        """
        初始化残差块。
        :param in_channels: 输入通道数
        :param out_channels: 输出通道数
        :param kernel_size: 卷积核大小
        :param padding: 填充大小
        """
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, padding=padding)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=kernel_size, padding=padding)
        self.bn2 = nn.BatchNorm1d(out_channels)
        
        if in_channels != out_channels:
            self.shortcut = nn.Conv1d(in_channels, out_channels, kernel_size=1)
        else:
            self.shortcut = nn.Identity()
    
    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        shortcut = self.shortcut(x)
        out += shortcut
        out = F.relu(out)
        return out

# 定义 ResNet-CNN 分类模型
class ResNetSentiment(nn.Module):
    def __init__(self, vocab_size, embedding_dim, num_classes, num_blocks, num_filters, kernel_size):
        """
        初始化ResNet-CNN模型。
        :param vocab_size: 词汇表大小
        :param embedding_dim: 嵌入维度
        :param num_classes: 分类数
        :param num_blocks: 残差块数量
        :param num_filters: 卷积核数量
        :param kernel_size: 卷积核大小
        """
        super(ResNetSentiment, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.conv_initial = nn.Conv1d(embedding_dim, num_filters, kernel_size=kernel_size, padding=kernel_size//2)
        self.bn_initial = nn.BatchNorm1d(num_filters)
        
        self.residual_blocks = nn.Sequential(
            *[ResidualBlock(num_filters, num_filters, kernel_size, padding=kernel_size//2) for _ in range(num_blocks)]
        )
        
        self.global_pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Linear(num_filters, num_classes)
    
    def forward(self, x):
        """
        前向传播。
        :param x: 输入张量 [batch_size, seq_len]
        :return: 输出张量 [batch_size, num_classes]
        """
        embedded = self.embedding(x)  # [batch_size, seq_len, embedding_dim]
        embedded = embedded.permute(0, 2, 1)  # [batch_size, embedding_dim, seq_len]
        out = F.relu(self.bn_initial(self.conv_initial(embedded)))  # [batch_size, num_filters, seq_len]
        out = self.residual_blocks(out)  # [batch_size, num_filters, seq_len]
        out = self.global_pool(out).squeeze(2)  # [batch_size, num_filters]
        out = self.fc(out)  # [batch_size, num_classes]
        return out

# 自定义 collate_fn
def collate_fn(batch):
    """
    自定义批处理函数，用于处理不同长度的序列。
    """
    if all(len(item) == 2 for item in batch):  # 检查每个item是否有两个元素
        tokens, labels = zip(*batch)  # 假设每个item是 (token, label)
        labels = torch.tensor(labels, dtype=torch.long)
    else:
        tokens = batch  # 假设每个item只是tokens
        labels = None

    tokens_padded = pad_sequence([torch.tensor(t, dtype=torch.long) for t in tokens], batch_first=True, padding_value=0)

    if labels is not None:
        return tokens_padded, labels
    return tokens_padded

# 训练模型
def train_model(model, train_loader, val_loader, optimizer, criterion, num_epochs):
    """
    训练和验证模型。
    :param model: 模型
    :param train_loader: 训练数据加载器
    :param val_loader: 验证数据加载器
    :param optimizer: 优化器
    :param criterion: 损失函数
    :param num_epochs: 训练轮数
    :return: 训练和验证的损失及准确率列表
    """
    model.to(device)
    train_losses = []
    val_losses = []
    train_accuracies = []
    val_accuracies = []
    
    for epoch in range(num_epochs):
        model.train()
        epoch_loss = 0
        epoch_corrects = 0
        all_preds = []
        all_labels = []
        
        print(f"\nEpoch {epoch + 1}/{num_epochs}")
        logging.info(f"Epoch {epoch + 1}/{num_epochs}")
        print("-" * 30)
        logging.info("-" * 30)
        
        # 训练阶段
        for tokens_padded, labels in tqdm(train_loader, desc="Training", leave=False):
            try:
                optimizer.zero_grad()
                tokens_padded = tokens_padded.to(device)
                labels = labels.to(device)
                
                outputs = model(tokens_padded)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                
                epoch_loss += loss.item() * tokens_padded.size(0)
                _, preds = torch.max(outputs, 1)
                epoch_corrects += torch.sum(preds == labels).item()
                
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
            except Exception as e:
                logging.error(f"Error during training batch processing: {e}")
                print(f"Error during training batch processing: {e}")
                continue
        
        epoch_loss = epoch_loss / len(train_loader.dataset)
        train_losses.append(epoch_loss)  # 记录训练损失
        epoch_acc = accuracy_score(all_labels, all_preds)
        train_accuracies.append(epoch_acc)  # 记录训练准确率
        
        epoch_precision = precision_score(all_labels, all_preds, average='binary')
        epoch_recall = recall_score(all_labels, all_preds, average='binary')
        epoch_f1 = f1_score(all_labels, all_preds, average='binary')
        
        print(f"Training Loss: {epoch_loss:.4f} | Accuracy: {epoch_acc:.4f} | Precision: {epoch_precision:.4f} | Recall: {epoch_recall:.4f} | F1-Score: {epoch_f1:.4f}")
        logging.info(f"Training Loss: {epoch_loss:.4f} | Accuracy: {epoch_acc:.4f} | Precision: {epoch_precision:.4f} | Recall: {epoch_recall:.4f} | F1-Score: {epoch_f1:.4f}")
        print("Training Classification Report:")
        report = classification_report(all_labels, all_preds, target_names=['neg', 'pos'])
        print(report)
        logging.info("Training Classification Report:")
        logging.info(report)
        
        # 验证阶段
        model.eval()
        val_loss = 0
        val_corrects = 0
        all_val_preds = []
        all_val_labels = []
        
        with torch.no_grad():
            for tokens_padded, labels in tqdm(val_loader, desc="Validation", leave=False):
                try:
                    tokens_padded = tokens_padded.to(device)
                    labels = labels.to(device)
                    
                    outputs = model(tokens_padded)
                    loss = criterion(outputs, labels)
                    
                    val_loss += loss.item() * tokens_padded.size(0)
                    _, preds = torch.max(outputs, 1)
                    val_corrects += torch.sum(preds == labels).item()
                    
                    all_val_preds.extend(preds.cpu().numpy())
                    all_val_labels.extend(labels.cpu().numpy())
                except Exception as e:
                    logging.error(f"Error during validation batch processing: {e}")
                    print(f"Error during validation batch processing: {e}")
                    continue
        
        val_loss = val_loss / len(val_loader.dataset)
        val_losses.append(val_loss)  # 记录验证损失
        val_acc = accuracy_score(all_val_labels, all_val_preds)
        val_accuracies.append(val_acc)  # 记录验证准确率
        
        val_precision = precision_score(all_val_labels, all_val_preds, average='binary')
        val_recall = recall_score(all_val_labels, all_val_preds, average='binary')
        val_f1 = f1_score(all_val_labels, all_val_preds, average='binary')
        
        print(f"Validation Loss: {val_loss:.4f} | Accuracy: {val_acc:.4f} | Precision: {val_precision:.4f} | Recall: {val_recall:.4f} | F1-Score: {val_f1:.4f}")
        logging.info(f"Validation Loss: {val_loss:.4f} | Accuracy: {val_acc:.4f} | Precision: {val_precision:.4f} | Recall: {val_recall:.4f} | F1-Score: {val_f1:.4f}")
        print("Validation Classification Report:")
        report = classification_report(all_val_labels, all_val_preds, target_names=['neg', 'pos'])
        print(report)
        logging.info("Validation Classification Report:")
        logging.info(report)
    
    return train_losses, val_losses, train_accuracies, val_accuracies

# 预测函数
def predict(model, data_loader, label_map):
    """
    对未标记的数据进行预测。
    :param model: 训练好的模型
    :param data_loader: 数据加载器
    :param label_map: 标签映射字典
    :return: 预测结果列表
    """
    model.eval()
    predictions = []
    with torch.no_grad():
        for batch in tqdm(data_loader, desc="Predicting", leave=False):
            try:
                if isinstance(batch, tuple) and len(batch) == 2:
                    tokens_padded, _ = batch
                else:
                    tokens_padded = batch  # 假设batch返回的是tokens
                
                tokens_padded = tokens_padded.to(device)
                
                outputs = model(tokens_padded)
                _, preds = torch.max(outputs, 1)
                predicted_labels = [label_map[idx.item()] for idx in preds]
                predictions.extend(predicted_labels)
            except Exception as e:
                logging.error(f"Error during prediction batch processing: {e}")
                print(f"Error during prediction batch processing: {e}")
                continue
    return predictions

# 预处理未标记的评论
def preprocess_unlabeled_reviews(file_name, vocab):
    """
    预处理未标记的评论数据。
    :param file_name: 未标记评论文件路径
    :param vocab: 词汇表字典
    :return: ReviewsDataset对象
    """
    try:
        logging.info(f"Reading unlabeled reviews from {file_name}...")
        print(f"Reading unlabeled reviews from {file_name}...")
        reviews = pd.read_csv(file_name)
        print(f"Number of unlabeled reviews: {len(reviews)}")
        logging.info(f"Number of unlabeled reviews: {len(reviews)}")
        reviews['content'] = reviews['comment'].apply(clean_text)
        reviews['tokens'] = reviews['content'].apply(tokenize)
        return ReviewsDataset(reviews, vocab, include_labels=False)  # 使用标志位
    except Exception as e:
        logging.error(f"Error during preprocessing unlabeled reviews: {e}")
        print(f"Error during preprocessing unlabeled reviews: {e}")
        sys.exit(1)

# 主函数
def main():
    neg_file = 'data/negative.txt'
    pos_file = 'data/positive.txt'
    
    # 检查数据文件是否存在
    for file in [neg_file, pos_file]:
        if not os.path.exists(file):
            logging.error(f"Error: {file} does not exist.")
            print(f"Error: {file} does not exist.")
            sys.exit(1)
    
    print("Preprocessing training data...")
    logging.info("Preprocessing training data...")
    reviews = preprocess_reviews(neg_file, pos_file)
    
    print("Building vocabulary...")
    logging.info("Building vocabulary...")
    vocab = build_vocab(reviews)
    
    print("Creating dataset...")
    logging.info("Creating dataset...")
    dataset = ReviewsDataset(reviews, vocab)
    
    # 划分训练集和验证集（例如，90%训练，10%验证）
    train_size = int(0.9 * len(dataset))
    val_size = len(dataset) - train_size
    print(f"Training samples: {train_size}, Validation samples: {val_size}")
    logging.info(f"Training samples: {train_size}, Validation samples: {val_size}")
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])
    
    # 创建 DataLoader
    train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=10, shuffle=False, collate_fn=collate_fn)
    
    # 定义 ResNet-CNN 模型
    model = ResNetSentiment(
        vocab_size=len(vocab) + 1,  # +1 为 <pad> token
        embedding_dim=100,           # 嵌入维度
        num_classes=2,               # 二分类
        num_blocks=3,                # 残差块数量
        num_filters=128,             # 卷积核数量
        kernel_size=3                # 卷积核大小
    )
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    print("Starting training...")
    logging.info("Starting training...")
    
    # 训练并记录损失和准确率
    train_losses, val_losses, train_accuracies, val_accuracies = train_model(
        model, train_loader, val_loader, optimizer, criterion, num_epochs=10
    )
    
    # 绘制损失和准确率曲线
    epochs = range(1, len(train_losses) + 1)
    
    plt.figure(figsize=(12, 5))
    
    # 绘制损失曲线
    plt.subplot(1, 2, 1)
    plt.plot(epochs, train_losses, 'bo-', label='Training Loss')
    plt.plot(epochs, val_losses, 'ro-', label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    # 绘制准确率曲线
    plt.subplot(1, 2, 2)
    plt.plot(epochs, train_accuracies, 'bo-', label='Training Accuracy')
    plt.plot(epochs, val_accuracies, 'ro-', label='Validation Accuracy')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    
    # 确保保存路径存在
    save_dir = 'res'
    os.makedirs(save_dir, exist_ok=True)
    
    plt.savefig(os.path.join(save_dir, 'ResNet_loss_accuracy_curve.png'))  # 保存为图片
    print("Loss and accuracy curves saved as '{save_path}'.")
    logging.info("Loss and accuracy curves saved as '{save_path}'.")
    
    # 加载未标记的数据集并进行预测
    unlabeled_file = 'data/1000.csv'
    if not os.path.exists(unlabeled_file):
        logging.error(f"Error: {unlabeled_file} does not exist.")
        print(f"Error: {unlabeled_file} does not exist.")
        sys.exit(1)
    
    unlabeled_dataset = preprocess_unlabeled_reviews(unlabeled_file, vocab)
    unlabeled_data_loader = DataLoader(unlabeled_dataset, batch_size=10, shuffle=False, collate_fn=collate_fn)
    
    print("Making predictions...")
    logging.info("Making predictions...")
    predictions = predict(model, unlabeled_data_loader, {0: 'neg', 1: 'pos'})
    
    # 保存预测结果到CSV文件
    try:
        output_df = pd.DataFrame({
            'content': [data['content'] for data in unlabeled_data_loader.dataset.reviews.to_dict('records')],
            'predicted_label': predictions
        })
        output_path = 'ResNet_predicted_reviews.csv'
        output_df.to_csv(output_path, index=False)
        logging.info(f"Predictions saved to '{output_path}'.")
        print(f"Predictions saved to '{output_path}'.")
    except Exception as e:
        logging.error(f"Error during saving predictions: {e}")
        print(f"Error during saving predictions: {e}")

if __name__ == "__main__":
    main()