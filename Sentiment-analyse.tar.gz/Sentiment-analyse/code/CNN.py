import pandas as pd
import re
import jieba.posseg as psg
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.optim as optim
from torch.nn.utils.rnn import pad_sequence
import torch.nn.functional as F
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import matplotlib.pyplot as plt
import os
import sys

# 检查设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# 文本清洗
def clean_text(text):
    # 去除英文、数字和空白字符
    pattern = re.compile('[a-zA-Z0-9]+|[\s]+')
    return pattern.sub('', text)

# 分词
def tokenize(text):
    return ' '.join([x.word for x in psg.cut(text)])

# 数据预处理
def preprocess_reviews(neg_file, pos_file):
    # 读取负面评论
    with open(neg_file, 'r', encoding='utf-8') as file:
        neg_reviews = file.readlines()
    neg_reviews = [clean_text(line.strip()) for line in neg_reviews]
    
    # 读取正面评论
    with open(pos_file, 'r', encoding='utf-8') as file:
        pos_reviews = file.readlines()
    pos_reviews = [clean_text(line.strip()) for line in pos_reviews]
    
    # 创建DataFrame
    data = {'comment': neg_reviews + pos_reviews,
            'label': [0] * len(neg_reviews) + [1] * len(pos_reviews)}
    df = pd.DataFrame(data)
    df['tokens'] = df['comment'].apply(tokenize)
    return df

# 建立词汇表
def build_vocab(reviews):
    vocab = {}
    for tokens in reviews['tokens']:
        for word in tokens.split():
            if word not in vocab:
                vocab[word] = len(vocab) + 1  # 词汇表索引从1开始
    vocab['<pad>'] = 0
    return vocab

# 定义数据集类
class ReviewsDataset(Dataset):
    def __init__(self, reviews, vocab, include_labels=True):
        self.reviews = reviews
        self.vocab = vocab
        self.include_labels = include_labels  # 标记是否包含标签

    def __len__(self):
        return len(self.reviews)

    def __getitem__(self, idx):
        tokens = [self.vocab.get(word, 0) for word in self.reviews.iloc[idx]['tokens'].split()]
        tokens_tensor = torch.tensor(tokens, dtype=torch.long)
        if self.include_labels:
            label = self.reviews.iloc[idx]['label']
            return tokens_tensor, torch.tensor(label, dtype=torch.long)
        return tokens_tensor

# 定义 CNN 分类模型
class CNNModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, num_classes, kernel_num=100, kernel_sizes=[3,4,5], dropout=0.5):
        super(CNNModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv2d(1, kernel_num, (k, embedding_dim)) for k in kernel_sizes
        ])
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(len(kernel_sizes) * kernel_num, num_classes)
    
    def forward(self, x):
        embedded = self.embedding(x)  # [batch_size, seq_len, embedding_dim]
        embedded = embedded.unsqueeze(1)  # [batch_size, 1, seq_len, embedding_dim]
        conved = [F.relu(conv(embedded)).squeeze(3) for conv in self.convs]  # List of [batch_size, kernel_num, seq_len - k +1]
        pooled = [F.max_pool1d(c, c.size(2)).squeeze(2) for c in conved]  # List of [batch_size, kernel_num]
        cat = torch.cat(pooled, dim=1)  # [batch_size, kernel_num * len(kernel_sizes)]
        dropped = self.dropout(cat)
        out = self.fc(dropped)  # [batch_size, num_classes]
        return out

# 自定义 collate_fn
def collate_fn(batch):
    if all(len(item) == 2 for item in batch):  # 检查每个item是否有两个元素
        tokens, labels = zip(*batch)  # 假设每个item是 (token, label)
        labels = torch.tensor(labels, dtype=torch.long)
    else:
        tokens = batch  # 假设每个item只是tokens
        labels = None

    tokens_padded = pad_sequence([torch.tensor(t, dtype=torch.long) for t in tokens], batch_first=True, padding_value=0)

    if labels is not None:
        return tokens_padded, labels
    return tokens_padded

# 训练模型
def train_model(model, train_loader, val_loader, optimizer, criterion, num_epochs):
    model.to(device)
    train_losses = []
    val_losses = []
    train_accuracies = []
    val_accuracies = []
    
    for epoch in range(num_epochs):
        model.train()
        epoch_loss = 0
        epoch_corrects = 0
        total = 0
        progress_bar = tqdm(train_loader, desc=f"Epoch {epoch + 1}/{num_epochs} - Training", leave=False)
        
        for batch in progress_bar:
            optimizer.zero_grad()
            
            tokens_padded, labels = batch
            tokens_padded = tokens_padded.to(device)
            labels = labels.to(device)
            
            outputs = model(tokens_padded)
            loss = criterion(outputs, labels)
            _, preds = torch.max(outputs, 1)
            
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item() * tokens_padded.size(0)
            epoch_corrects += torch.sum(preds == labels).item()
            total += labels.size(0)
            
            progress_bar.set_postfix({'loss': loss.item()})
        
        epoch_loss = epoch_loss / len(train_loader.dataset)
        epoch_acc = epoch_corrects / len(train_loader.dataset)
        train_losses.append(epoch_loss)
        train_accuracies.append(epoch_acc)
        
        print(f"\nEpoch {epoch + 1}/{num_epochs} - Training Loss: {epoch_loss:.4f} | Training Accuracy: {epoch_acc:.4f}")
        
        # 验证阶段
        model.eval()
        val_loss = 0
        val_corrects = 0
        with torch.no_grad():
            for batch in tqdm(val_loader, desc=f"Epoch {epoch + 1}/{num_epochs} - Validation", leave=False):
                tokens_padded, labels = batch
                tokens_padded = tokens_padded.to(device)
                labels = labels.to(device)
                
                outputs = model(tokens_padded)
                loss = criterion(outputs, labels)
                _, preds = torch.max(outputs, 1)
                
                val_loss += loss.item() * tokens_padded.size(0)
                val_corrects += torch.sum(preds == labels).item()
        
        val_loss = val_loss / len(val_loader.dataset)
        val_acc = val_corrects / len(val_loader.dataset)
        val_losses.append(val_loss)
        val_accuracies.append(val_acc)
        
        print(f"Epoch {epoch + 1}/{num_epochs} - Validation Loss: {val_loss:.4f} | Validation Accuracy: {val_acc:.4f}")
    
    return train_losses, val_losses, train_accuracies, val_accuracies

# 预测函数
def predict(model, data_loader, label_map):
    model.to(device)
    model.eval()
    predictions = []
    
    with torch.no_grad():
        for batch in tqdm(data_loader, desc="Predicting"):
            if isinstance(batch, tuple) and len(batch) == 2:
                tokens_padded, _ = batch
            else:
                tokens_padded = batch  # 假设batch返回的是tokens
            
            tokens_padded = tokens_padded.to(device)
            
            outputs = model(tokens_padded)
            _, preds = torch.max(outputs, 1)
            predicted_labels = [label_map[idx.item()] for idx in preds]
            predictions.extend(predicted_labels)
    
    return predictions

# 预处理未标记的评论
def preprocess_unlabeled_reviews(file_name, vocab):
    reviews = pd.read_csv(file_name)
    reviews['content'] = reviews['comment'].apply(clean_text)
    reviews['tokens'] = reviews['content'].apply(tokenize)
    return ReviewsDataset(reviews, vocab, include_labels=False)  # 使用标志位

# 主函数
def main():
    neg_file = 'data/negative.txt'
    pos_file = 'data/positive.txt'
    
    print("Preprocessing training data...")
    reviews = preprocess_reviews(neg_file, pos_file)
    
    print("Building vocabulary...")
    vocab = build_vocab(reviews)
    
    print("Creating dataset...")
    dataset = ReviewsDataset(reviews, vocab)
    
    # 划分训练集和验证集（例如，90%训练，10%验证）
    train_size = int(0.9 * len(dataset))
    val_size = len(dataset) - train_size
    print(f"Training samples: {train_size}, Validation samples: {val_size}")
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])
    
    # 创建 DataLoader
    train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=10, shuffle=False, collate_fn=collate_fn)
    
    print("Initializing CNN model...")
    model = CNNModel(
        vocab_size=len(vocab) + 1, 
        embedding_dim=100, 
        num_classes=2, 
        kernel_num=100, 
        kernel_sizes=[3,4,5], 
        dropout=0.5
    )  # 使用 CNN 模型
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    print("Starting training...")
    train_losses, val_losses, train_accuracies, val_accuracies = train_model(
        model, train_loader, val_loader, optimizer, criterion, num_epochs=10
    )
    
    # 绘制损失和准确率曲线
    epochs = range(1, len(train_losses) + 1)
    
    plt.figure(figsize=(12,5))
    
    # 绘制损失曲线
    plt.subplot(1, 2, 1)
    plt.plot(epochs, train_losses, 'bo-', label='Training Loss')
    plt.plot(epochs, val_losses, 'ro-', label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    # 绘制准确率曲线
    plt.subplot(1, 2, 2)
    plt.plot(epochs, train_accuracies, 'bo-', label='Training Accuracy')
    plt.plot(epochs, val_accuracies, 'ro-', label='Validation Accuracy')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.savefig('res/CNN_loss_curves.png')  # 保存为图片
    print("Training and validation curves saved as 'training_validation_curves.png'.")
    
    # 进行预测
    print("Preprocessing unlabeled data for prediction...")
    unlabeled_data_loader = DataLoader(
        preprocess_unlabeled_reviews('data/1000.csv', vocab), 
        batch_size=10, 
        shuffle=False, 
        collate_fn=collate_fn
    )
    
    print("Making predictions...")
    predictions = predict(model, unlabeled_data_loader, {0: 'neg', 1: 'pos'})
    
    print("Saving predictions to 'CNN_predicted_reviews.csv'...")
    output_df = pd.DataFrame({
        'content': [data['content'] for data in unlabeled_data_loader.dataset.reviews.to_dict('records')],
        'predicted_label': predictions
    })
    output_df.to_csv('CNN_predicted_reviews.csv', index=False)
    
    print("Predictions saved to 'CNN_predicted_reviews.csv'.")

if __name__ == "__main__":
    main()